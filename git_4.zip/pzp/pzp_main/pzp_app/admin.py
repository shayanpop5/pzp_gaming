from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DefaultUserAdmin


from models import Person


@admin.register(Person)
class UserAdmin(DefaultUserAdmin):
    list_display = ['username', 'email', 'first_name', 'last_name', 'is_staff', 'is_active']
    list_filter = ['is_staff','is_superuser','is_active',]
    list_editable = ['is_staff','is_active']

    fieldsets = (

        (None, {
            'fields': ('username', 'password')
            }),

        ('Personal info', {
            'fields': ('first_name', 'last_name', 'email',)
        }),

        ('Contact info', {
            'fields': ('phone', 'address',)
        }),
        
    )