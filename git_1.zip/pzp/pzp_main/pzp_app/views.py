from django.shortcuts import HttpResponse
from django.shortcuts import render



def home_view(request):
    context = {"author": "Shayan Zamani",}
    return render(request, "index.html", context=context)

def game_view(request):
    return HttpResponse('game_view')

def video_view(request):
    return HttpResponse('video_view')

def my_profile_view(request):
    return HttpResponse('my_profile_view')



def signup_view(request):
    return HttpResponse('Signup Completed!')