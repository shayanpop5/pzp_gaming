from django.contrib import admin
from django.urls import path, include

from pzp_app.views import *

urlpatterns = [
    path('admin/', admin.site.urls),
    path('signup/', signup_view),
    path('home/', home_view),
    path('game/', game_view),
    path('video/', video_view),
    path('profile/', my_profile_view),
]
