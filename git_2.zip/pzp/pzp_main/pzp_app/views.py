from django.shortcuts import HttpResponse
from django.shortcuts import render



def home_view(request):
    context = {"author": "Shayan Zamani",}
    return render(request, "index.html", context=context)

def division_2(request):
    return HttpResponse('division_2')

def contact(request):
    return HttpResponse('contact')

def my_profile_view(request):
    return HttpResponse('my_profile_view')



def signup_view(request):
    return HttpResponse('Signup Completed!')