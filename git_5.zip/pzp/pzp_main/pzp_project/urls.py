
from django.contrib import admin
from django.urls import path, include
from pzp_app import views as user_view
from django.contrib.auth import views as auth
from pzp_app.views import *


urlpatterns = [
    path('admin/', admin.site.urls),
    path('profile',include('pzp_app.urls')),
    path('', home_view),
    path('home/', home_view),
    path('home/profile', include('pzp_app.urls')),
    path('division_2/', division_2),
    path('division_2/about_us', About_US),
    path('division_2/home', home_view),
    path('home/division_2/home', home_view),
    path('home/division_2/', division_2),
    path('about_us/', About_US),
    path('about_us/about_us/', About_US),
    path('about_us/home', home_view),
    path('about_us/division_2', division_2),
    path('home/division_2/about_us/', About_US),
    path('home/about_us/division_2/', division_2),
    path('home/about_us/', About_US),
    path('profile/', my_profile_view),
    ##### user related path##########################
    
    path('login/', user_view.Login, name ='login'),
    path('logout/', auth.LogoutView.as_view(template_name ='index.html'), name ='logout'),
    path('register/', user_view.register, name ='register'),
]
