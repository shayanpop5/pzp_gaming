EMAIL_USE_TLS = True
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_HOST_USER = 'gfg.demo.django.login'
EMAIL_HOST_PASSWORD = 'gfgdemo123'
EMAIL_PORT = 587