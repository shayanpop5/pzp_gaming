# ℹ️ KogPlayGame's

The kogplaygame's is a website for game selling platform. This Website contain Game's user can Buy and play it. This Website also sell Xbox,Playstation,Pc's Games.

---

# 👁️‍🗨️ Preview of KogPlayGame's Website

https://user-images.githubusercontent.com/66934377/160538840-817a5243-8a40-43d9-a7a6-9e5bd21f70c4.mp4

---

# 📱 Preview of Website Response

The Kogplaygame's is fully responsive design. It can render any type of Device like MobilePhone,Laptop,Desktop,Tablet etc.

https://user-images.githubusercontent.com/66934377/160539011-72b3c1e4-ea24-448e-a6cb-49a1aaadab45.mp4

---

# 🗂️ Framework 

The Below Table Framework is used in this project. This Project is made with Bootstrap Framework

| Framework  | Version |
| ------------- | ------------- |
| Bootstrap  | 5.1.3  |

---

# ⬇️ Code Downloading Process

* You Can Download the code in **2 Methods**
* Choose Any One Methode has your whish

---

# Ⓜ️ Methode 1

* **This Methode is Very Easy**

* Now Click on __Code Option__

![Screenshot (158)](https://user-images.githubusercontent.com/66934377/164152919-f2854829-535d-4227-9c2f-031f8051f6ac.png)

* Now A Screen will Popup. Now Click **Download Zip** Option . Now the file has been started downloading 

![Screenshot (159)](https://user-images.githubusercontent.com/66934377/164153128-b64e85a2-e40c-4457-9835-a749ac79acd6.png)

---

# Ⓜ️ Methode 2

* **This Methode is tittle bit Hard**

* Now Open **cmd** in windows, **bash Terminal** in mac. Now Hit the Below Command's

```bash
git clone https://github.com/Manju1392k/KOGPlayGame-s-Website.git
```

* The project cloned after this process



