from django.shortcuts import HttpResponse
from django.shortcuts import render



def home_view(request):
    context = {"author": "Shayan Zamani",}
    return render(request, "index.html", context=context)

def division_2(request):
    context = {"author": "Shayan Zamani",}
    return render(request, "division_2.html", context=context)

def About_US(request):
    context = {"author": "Shayan Zamani",}
    return render(request, "About_US.html", context=context)

def my_profile_view(request):
    return HttpResponse('my_profile_view')



def signup_view(request):
    return HttpResponse('Signup Completed!')